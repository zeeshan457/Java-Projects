
import javax.swing.JTextField;

/**
 *
 * @author Aneef
 */
public class Data_Logic {

    public void clear(JTextField name, JTextField address, JTextField number,
            JTextField time, JTextField help) {

        name.setText("");
        address.setText("");
        number.setText("");
        time.setText("");
        help.setText("");

    }

}
