
/**
 *
 * @author Aneef
 */
public class launcher {

    public static void main(String[] args) {
        main_GUI main = new main_GUI();

    }

}
